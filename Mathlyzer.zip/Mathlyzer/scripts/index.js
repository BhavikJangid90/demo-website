// index.js

const scanButton = document.getElementById('scanButton');
const uploadButton = document.getElementById('uploadButton');
const speakButton = document.getElementById('speakButton');
const modal = document.getElementById('modal');
const modalTitle = document.getElementById('modalTitle');
const modalDescription = document.getElementById('modalDescription');

scanButton.addEventListener('click', () => {
  openModal('Scan a Problem', 'Use your camera to scan your math problem.');
});

uploadButton.addEventListener('click', () => {
  openModal('Upload a Problem', 'Upload a picture or file of your math problem.');
});

speakButton.addEventListener('click', () => {
  openModal('Speak a Problem', 'Speak your math problem clearly into the microphone.');
});

function openModal(title, description) {
  modalTitle.innerText = title;
  modalDescription.innerText = description;
  modal.classList.remove('hidden');
  modal.classList.add('flex');
}

function closeModal() {
  modal.classList.add('hidden');
  modal.classList.remove('flex');
}
